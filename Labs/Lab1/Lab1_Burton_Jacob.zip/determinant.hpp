/***************************************************************************************
** Program name:  Lab 1 - determinant.hpp
** Author:  Jacob Burton
** Date:  04/07/2019
** Description:  Header file for detrminant function
****************************************************************************************/

#ifndef DETERMINANT_HPP
#define DETERMINANT_HPP

int determinant(int** arr, int size); // determinant function prototype
	
#endif